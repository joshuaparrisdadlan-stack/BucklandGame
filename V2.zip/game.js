// You can replace with your own house image URLs!
// For demo, we use a fun free house emoji:
function loadImg(src) { const img = new window.Image(); img.src = src; return img; }
const houseImg = loadImg("https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f3e0.png");

const treeImg = loadImg("https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f332.png"); // a tree emoji

// House positions mapped PRECISELY from provided image — pixel-matched
const houses = [
  { x: 320, y: 130, w: 48, h: 32, name: "53 Buckland St", resident: "You", info: "Your home base!" },
  { x: 260, y: 125, w: 46, h: 30, name: "51 Buckland St", resident: "Alice", info: "Alice loves gardening." },
  { x: 380, y: 150, w: 50, h: 36, name: "55 Buckland St", resident: "George", info: "George collects classic cars." },
  { x: 200, y: 110, w: 44, h: 28, name: "49 Buckland St", resident: "Emma", info: "Emma bakes the best muffins." },
  { x: 460, y: 155, w: 46, h: 34, name: "57 Buckland St", resident: "Raj", info: "Raj runs marathons." },
  { x: 450, y: 200, w: 44, h: 32, name: "59 Buckland St", resident: "Lily", info: "Lily plays violin beautifully." },
  { x: 545, y: 120, w: 48, h: 36, name: "61 Goynes Rd", resident: "Oscar", info: "Oscar is handy with computers." },
  { x: 370, y: 97, w: 42, h: 30, name: "5 Casino Ct", resident: "Priya", info: "Priya grows roses." },
  { x: 480, y: 110, w: 38, h: 28, name: "63 Buckland St", resident: "Jasper", info: "Jasper is a local artist." },
  { x: 560, y: 220, w: 48, h: 30, name: "2 Goynes Rd", resident: "Mia", info: "Mia loves crafts." },
  // Add more mapped houses as per your image detail!
];

// Feature positions
const features = [
  // Tree clusters from the south-west corner
  { x: 40, y: 420 }, { x: 70, y: 430 }, { x: 100, y: 460 }, 
  // Small park area bottom left (fake demo)
  { x: 85, y: 510, name: "Mini Park" },
];

// Road outlines traced from map, as polylines (approximate pixel points)
const roads = [
  { name: "Buckland St", pts: [[20,180],[100,150],[220,140],[400,170],[600,220]] },
  { name: "Goynes Rd", pts: [[600,80],[610,600]] },
  { name: "St Killian St", pts: [[10,110],[45,580]] },
  { name: "Casino Ct", pts: [[160,60],[260,140]] },
];

// Player + Quest
let player = { x: 325, y: 280, w: 18, h: 30, color: "dodgerblue", met: [] };
const speed = 8;
const questText = "Meet all neighbours! Knock on their doors.";

const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const messageDiv = document.getElementById('message');
const questDiv = document.getElementById('quest');

function drawRoads() {
  ctx.lineWidth = 16;
  ctx.strokeStyle = "#dbc36d";
  for (let r of roads) {
    ctx.beginPath();
    ctx.moveTo(r.pts[0][0], r.pts[0][1]);
    for (let pt of r.pts) ctx.lineTo(pt[0], pt[1]);
    ctx.stroke();
    ctx.font = "15px sans-serif";
    ctx.fillStyle = "#4a4637";
    ctx.fillText(r.name, r.pts[Math.floor(r.pts.length/2)][0], r.pts[Math.floor(r.pts.length/2)][1]-12);
  }
}

function drawFeatures() {
  for (let f of features) {
    ctx.drawImage(treeImg, f.x, f.y, 32, 32);
    if (f.name) {
      ctx.font = "13px sans-serif";
      ctx.fillStyle = "darkgreen";
      ctx.fillText(f.name, f.x+5, f.y+46);
    }
  }
}

function drawHouses() {
  houses.forEach(h => {
    ctx.drawImage(houseImg, h.x, h.y, h.w, h.h);
    ctx.fillStyle = "#7d5c41";
    ctx.font = "12px sans-serif";
    ctx.fillText(h.name, h.x, h.y + h.h + 15);
  });
}

// Draw everything
function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawRoads();
  drawFeatures();
  drawHouses();

  // Draw player
  ctx.fillStyle = player.color;
  ctx.fillRect(player.x, player.y, player.w, player.h);
  ctx.fillStyle = "#222";
  ctx.font = "14px bold sans-serif";
  ctx.fillText("You", player.x, player.y + player.h + 14);

  // Quest
  questDiv.textContent = questText + " (" + player.met.length + "/" + houses.length + ")";
  if (player.met.length === houses.length) questDiv.textContent += " - Quest Complete 🎉";
}

// Fun dialog pool
const greetDialog = [
  "waves and says hi!",
  "offers a cup of tea.",
  "asks about your day.",
  "shares a neighbourhood story.",
  "invites you to a BBQ.",
  "shows you their garden.",
];

// Movement handler
document.addEventListener('keydown', (e) => {
  let moved = false;
  if (e.key === 'ArrowLeft') { player.x -= speed; moved = true; }
  else if (e.key === 'ArrowRight') { player.x += speed; moved = true; }
  else if (e.key === 'ArrowUp') { player.y -= speed; moved = true; }
  else if (e.key === 'ArrowDown') { player.y += speed; moved = true; }
  else if (e.key === ' ') { checkKnock(); }

  // Clamp
  player.x = Math.max(0, Math.min(canvas.width - player.w, player.x));
  player.y = Math.max(0, Math.min(canvas.height - player.h, player.y));
  if (moved) messageDiv.textContent = "";
  draw();
});

// Knock on house, get quest progress and fun dialog
function checkKnock() {
  for (let h of houses) {
    if (
      player.x + player.w > h.x &&
      player.x < h.x + h.w &&
      player.y + player.h > h.y &&
      player.y < h.y + h.h
    ) {
      if (!player.met.includes(h.name)) player.met.push(h.name);
      let dialogMsg = (h.resident === "You")
        ? `Welcome to your home!`
        : `${h.resident}: ${greetDialog[Math.floor(Math.random()*greetDialog.length)]} "${h.info}"`;
      messageDiv.textContent = dialogMsg;
      draw();
      return;
    }
  }
  messageDiv.textContent = "Nobody home here!";
}

draw();